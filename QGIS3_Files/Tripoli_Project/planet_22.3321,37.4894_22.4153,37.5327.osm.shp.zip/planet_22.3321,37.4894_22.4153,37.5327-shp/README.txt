Map data (c) OpenStreetMap contributors, https://www.openstreetmap.org
Extracts created by BBBike, https://extract.bbbike.org
osmium2shape by Geofabrik, https://geofabrik.de


Please read the OSM wiki how to use shape files.

  https://wiki.openstreetmap.org/wiki/Shapefiles


This shape file was created on: Wed 22 May 14:37:01 UTC 2024
GPS rectangle coordinates (lng,lat): 22.3321,37.4894 x 22.4153,37.5327
Script URL: https://extract.bbbike.org/?sw_lng=22.3321&sw_lat=37.4894&ne_lng=22.4153&ne_lat=37.5327&format=shp.zip&city=Greece&lang=en
Name of area: Greece


We appreciate any feedback, suggestions and a donation!
You can support us via PayPal or bank wire transfer.

  https://extract.bbbike.org/community.html

You can donate any free amount you want. We are happy for every donation,
for 5, 10, 20, or 50 Euro. Whatever you think the service is worth for you,
or you can afford. We need to raise 20 Euro (25 USD) by the end of the day or
600 Euro (700 USD) per month to cover the server costs.
Your donation helps to pay for hosting the service. Many thanks!

thanks, Wolfram Schneider

--
BBBike professional plans: https://extract.bbbike.org/support.html
Planet.osm extracts: https://extract.bbbike.org
BBBike Map Compare: https://mc.bbbike.org
